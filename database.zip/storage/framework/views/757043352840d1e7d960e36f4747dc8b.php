<!DOCTYPE html>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <head>
        <title>Create Activity</title>
    </head>
    <body>

    <h1>Create Activity</h1>

    <?php if(session('success')): ?>
        <p style="color:green"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

    <form action="/create-activity" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <label>Title</label><br>
    <input type="text" name="title"><br><br>

    <label>Description</label><br>
    <textarea name="description"></textarea><br><br>

    <label>Date</label><br>
    <input type="date" name="date"><br><br>

    <label>Location</label><br>
    <input type="text" name="location"><br><br>

    <label>Cover Image</label><br>
    <input type="file" name="image"><br><br>
    <?php if(auth()->user()->role === 'staff'): ?>     
        <button type="submit">Create Activity</button>          
    <?php endif; ?>
    <?php if(auth()->user()->role === 'studen'): ?>     
        only club Admin can create activity !    
    <?php endif; ?>

    </form>

    </body>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\activity-hub\resources\views/activities/create.blade.php ENDPATH**/ ?>